import React from 'react';
import {Link} from 'react-router-dom'

export default class JobListings extends React.Component {

  render(){
    return   <div className="page page--jobslist">
        <h2>Job Listings</h2>
        {/* render JobCard components here ... */}

      </div>
  }
}
